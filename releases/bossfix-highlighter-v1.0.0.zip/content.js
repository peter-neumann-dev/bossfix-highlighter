const c = {
  messages: [
    "Der Boss rettet wieder den Tag! 🎩",
    "Ohne BossFix läuft hier nix! 🚀",
    "Der Boss ist der echte Fixer! 🔧",
    "Wieder ein Projekt gerettet! 💪",
    "Boss-Mode aktiviert! 🎯",
    "Der Boss hat's wieder gerichtet! ⭐",
    "BossFix to the rescue! 🦸‍♂️",
    "Problemlöser #1 am Start! 🏆",
    "Chef-Qualität delivered! 💫",
    "Wenn Bossfix nicht hilft, hilft nichts mehr! 💼",
    "Wer braucht Superhelden, wenn es BossFix gibt? 🦸‍♂️",
    "Bug? Welcher Bug? BossFix ist da! 🔥",
    "Der Boss bringt Ordnung ins Chaos! 🎯",
    "Ein Commit wie kein anderer – BossFix approved! ✅",
    "Jeder BossFix – ein Treffer ins Schwarze. 🎯",
    "Der Boss höchstpersönlich hat sich drum gekümmert. 🤝",
    "Erneut bewiesen: BossFix > Hotfix! 🔧",
    "Selbst Bugs zittern vor BossFix. ❄️🐛",
    "BossFix: Debugging mit Stil. 😎",
    '„Boss-Faktor" aktiviert – Problem gelöst! 🛠️',
    "BossFix: Die Antwort auf alles. 🤔➡️✅",
    "Kein Bug ist sicher vor BossFix. 🕵️‍♂️🐛",
    "BossFix bringt den Glanz ins Repo! ✨",
    "Wo BossFix ist, ist Hoffnung. 🙌",
    "Jeder Commit ein Meisterwerk! 🎨"
  ],
  emojis: ["🚀", "🔥", "💥", "🚨", "🎩", "🪓"]
}, m = /* @__PURE__ */ new WeakSet();
let d = !1, u = null, l, o = null;
function g() {
  o = new Audio(chrome.runtime.getURL("the-bossfix.mp3")), o.volume = 0.5;
}
function x() {
  if (u) return;
  const e = document.createElement("div");
  e.className = "bossfix-toast", e.textContent = c.messages[Math.floor(Math.random() * c.messages.length)], document.body.appendChild(e), u = e, l !== void 0 && clearTimeout(l), l = window.setTimeout(() => {
    e.remove(), u = null, l = void 0;
  }, 3e3);
}
function B() {
  o && (o.currentTime = 0, o.play().catch(console.warn)), x();
}
function f(e) {
  return !(m.has(e) || e instanceof Element && ["SCRIPT", "STYLE", "NOSCRIPT", "IFRAME", "SVG"].includes(e.tagName) || e instanceof Element && e.classList && Array.from(e.classList).some(
    (s) => ["bossfix-highlighted", "bossfix-toast", "monaco-editor"].includes(s)
  ));
}
function p(e) {
  const s = document.createElement("span");
  s.className = "bossfix-highlighted", s.textContent = e;
  const t = document.createElement("span");
  return t.className = "boss-emoji", t.textContent = c.emojis[Math.floor(Math.random() * c.emojis.length)], s.appendChild(t), s.addEventListener("mouseenter", B), s;
}
function h(e) {
  var s;
  if (f(e))
    if (e.nodeType === Node.TEXT_NODE && e.nodeValue) {
      const t = e.nodeValue, n = /bossfix/gi;
      if (n.test(t)) {
        const r = document.createDocumentFragment();
        let i = 0, a;
        for (n.lastIndex = 0; (a = n.exec(t)) !== null; )
          a.index > i && r.appendChild(
            document.createTextNode(t.slice(i, a.index))
          ), r.appendChild(p(a[0])), i = n.lastIndex;
        i < t.length && r.appendChild(document.createTextNode(t.slice(i))), (s = e.parentNode) == null || s.replaceChild(r, e);
      }
    } else e.nodeType === Node.ELEMENT_NODE && (m.add(e), Array.from(e.childNodes).forEach(h));
}
g();
new MutationObserver((e) => {
  if (!d) {
    d = !0;
    try {
      e.forEach((s) => {
        s.addedNodes.forEach((t) => {
          t.nodeType === Node.ELEMENT_NODE && f(t) && h(t);
        });
      });
    } finally {
      d = !1;
    }
  }
}).observe(document.body, {
  childList: !0,
  subtree: !0,
  characterData: !0
});
h(document.body);
